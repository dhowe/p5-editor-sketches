function setup() {
  createCanvas(400, 500);
}

function draw() {
  background(220);
}