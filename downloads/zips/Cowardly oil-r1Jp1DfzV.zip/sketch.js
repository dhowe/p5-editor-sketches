function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(255);
  rect(50,50,50,50);
}


function draw() {
  background(220);
  rect(50, 50, 50, 50);
}