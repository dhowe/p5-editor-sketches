let grids = [];

// each grid object should have the following fields: 
//   { x, y, numRows, numCols, cellArray }

function setup() {
  createCanvas(900, 700);
  createGrid(100, 100, 7, 6);
  createGrid(600, 300, 5, 6);
  createGrid(300, 600, 9, 2);
  createGrid(700, 50, 2, 2);
}

function createGrid(gx, gy, cols, rows) {
  
}

function draw() {

}

function mouseReleased() {

}

function mouseDragged() {

}

function mouseMoved() {

}











