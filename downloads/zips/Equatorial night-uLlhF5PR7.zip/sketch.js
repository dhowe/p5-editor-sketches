 function setup() {

    createCanvas(200,200)
    background(255);

    // tests for your function
    let a = squared(1); // 1
    text(a, 20, 20);

    a = squared(3);   // 9
    text(a, 20, 40);

    a = squared(19); // 361
    text(a, 20, 60);
  }

  function squared(n) {

     // your code here
  }