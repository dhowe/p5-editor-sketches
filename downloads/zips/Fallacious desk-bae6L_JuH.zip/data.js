let raw = [{"cases":10,"lat":41.207,"long":145.267},{"cases":0,"lat":-43.398,"long":-136.497},{"cases":11,"lat":-69.863,"long":147.117},{"cases":10,"lat":78.239,"long":152.717},{"cases":0,"lat":61.799,"long":-65.776},{"cases":18,"lat":75.405,"long":162.707},{"cases":0,"lat":3.044,"long":-160.078},{"cases":15,"lat":-37.557,"long":133.72},{"cases":0,"lat":2.599,"long":-119.571},{"cases":0,"lat":-30.783,"long":-162.614},{"cases":19,"lat":-79.763,"long":-11.315},{"cases":15,"lat":-74.301,"long":177.862},{"cases":4,"lat":-40.114,"long":75.877},{"cases":14,"lat":-76.452,"long":41},{"cases":0,"lat":-0.009,"long":-166.838},{"cases":0,"lat":-53.331,"long":-141.699},{"cases":7,"lat":-13.188,"long":63.814},{"cases":14,"lat":-2.671,"long":6.545},{"cases":0,"lat":-72.705,"long":-141.891},{"cases":0,"lat":13.556,"long":-131.489},{"cases":13,"lat":-19.786,"long":86.999},{"cases":14,"lat":-7.31,"long":157.976},{"cases":8,"lat":-77.606,"long":175.551},{"cases":0,"lat":64.923,"long":-12.298},{"cases":0,"lat":-69.898,"long":-130.991},{"cases":0,"lat":44.48,"long":-5.008},{"cases":16,"lat":-70.87,"long":-16.306},{"cases":9,"lat":-84.23,"long":30.698},{"cases":10,"lat":87.182,"long":74.136},{"cases":13,"lat":23.508,"long":98.487},{"cases":0,"lat":-41.654,"long":-130.379},{"cases":0,"lat":78.324,"long":-104.58},{"cases":0,"lat":37.526,"long":-3.913},{"cases":15,"lat":-78.06,"long":-9.823},{"cases":0,"lat":-19.438,"long":-82.589},{"cases":0,"lat":-62.448,"long":-51.67},{"cases":0,"lat":84.807,"long":30.618},{"cases":0,"lat":82.82,"long":-71.7},{"cases":0,"lat":45.194,"long":-147.141},{"cases":19,"lat":-12.11,"long":152.036},{"cases":0,"lat":67.394,"long":38.835},{"cases":0,"lat":87.596,"long":-2.251},{"cases":0,"lat":75.11,"long":-24.589},{"cases":13,"lat":-77.724,"long":77.076},{"cases":11,"lat":-87.907,"long":80.916},{"cases":6,"lat":-56.377,"long":16.547},{"cases":8,"lat":37.421,"long":83.378},{"cases":10,"lat":-1.142,"long":150.054},{"cases":0,"lat":83.705,"long":-179.457},{"cases":8,"lat":-47.634,"long":125.271},{"cases":0,"lat":50.211,"long":-53.141},{"cases":13,"lat":-86.464,"long":162.022},{"cases":0,"lat":-68.251,"long":-117.133},{"cases":0,"lat":88.585,"long":12.457},{"cases":16,"lat":-28.067,"long":-9.939},{"cases":0,"lat":-46.272,"long":-42.223},{"cases":0,"lat":-25.405,"long":-103.172},{"cases":2,"lat":68.727,"long":159.677},{"cases":13,"lat":-43.961,"long":31.406},{"cases":0,"lat":-50.854,"long":-142.417},{"cases":1,"lat":-60.166,"long":145.146},{"cases":1,"lat":56.259,"long":101.654},{"cases":0,"lat":53.417,"long":-158.545},{"cases":0,"lat":-73.024,"long":-153.167},{"cases":0,"lat":-80.661,"long":-175.589},{"cases":4,"lat":34.336,"long":97.365},{"cases":0,"lat":-64.037,"long":-35.259},{"cases":19,"lat":-72.44,"long":149.765},{"cases":17,"lat":29.815,"long":53.522},{"cases":0,"lat":-37.512,"long":-17.643},{"cases":17,"lat":26.253,"long":96.889},{"cases":0,"lat":41.067,"long":-162.306},{"cases":13,"lat":-56.967,"long":107.214},{"cases":3,"lat":73.612,"long":129.425},{"cases":0,"lat":35.332,"long":-92.027},{"cases":0,"lat":-41.221,"long":-44.04},{"cases":6,"lat":24.993,"long":52.253},{"cases":0,"lat":-28.068,"long":-64.442},{"cases":2,"lat":8.342,"long":171.601},{"cases":3,"lat":46.548,"long":141.071},{"cases":2,"lat":85.91,"long":115.477},{"cases":0,"lat":-57.911,"long":-174.701},{"cases":0,"lat":89.918,"long":49.283},{"cases":0,"lat":64.839,"long":-4.836},{"cases":3,"lat":18.36,"long":149.086},{"cases":8,"lat":-16.423,"long":16.229},{"cases":0,"lat":25.201,"long":-171.295},{"cases":0,"lat":-47.978,"long":-107.964},{"cases":18,"lat":80.408,"long":154.807},{"cases":0,"lat":3.942,"long":-137.812},{"cases":2,"lat":-27.437,"long":58.421},{"cases":10,"lat":-7.223,"long":109.368},{"cases":0,"lat":36.805,"long":-19.687},{"cases":0,"lat":-11.835,"long":-91.289},{"cases":7,"lat":-14.879,"long":16.849},{"cases":0,"lat":14.358,"long":-45.175},{"cases":0,"lat":-83.262,"long":-85.138},{"cases":0,"lat":38.595,"long":-38.535},{"cases":0,"lat":-86.493,"long":-123.88},{"cases":0,"lat":24.829,"long":-62.781}];

class Bld {
  constructor(x,y,l) {
    this.x = x;
    this.y = y;
    this.label = l;
  }
  asVec() {
    return [this.x, this.y, 1];
  }
}

let buildings = raw.map(o => { 
  let x = o.lat/90;
  let y = o.long/180;
  let label = o.cases > 0 ? 0 : 1;
  return new Bld(x, y, label);
}); 

function scrX(x) {
  return map(x, -1, 1, 0, width);
}

function scrY(y) {
  return map(y, -1, 1, 0, height);
}

