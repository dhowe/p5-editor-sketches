function setup() {
  createCanvas(400, 400);
  print(RiTa.VERSION);
}
