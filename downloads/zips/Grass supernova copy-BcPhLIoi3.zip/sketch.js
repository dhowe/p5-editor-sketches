function setup() {
  createCanvas(400, 150);
}

function draw() {
  background(220);
  textSize(50);
  noFill();
  
  rect(0,100,400,100);
  fill(0)
  textAlign(CENTER);
  text("AAAAAAAAAA",200,50)
  text("AAAAAAAAAA",0,100,400,100)
  
}