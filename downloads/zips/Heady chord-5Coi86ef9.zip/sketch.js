function setup() {
  createCanvas(400, 400);
  stroke(255,0,0);
  line(24,25, 300, 200);
  stroke(0,0,255);
  line(124,125, 200, 200);
  
  rect(10,10,300,300);
}

