let eyes = [], hair = [], skin = [];

function preload() {
  // load the images
}

function setup() {
  createCanvas(1024, 768);
}

function draw() {
  background(220);
  
  drawFace(10, 10, 750, 550);
}

function drawFace(x, y, w, h) {
  
  //     ??? 
}









