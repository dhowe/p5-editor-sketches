function setup() {
  createCanvas(400, 400);
  let dotPos = new nVector(0, 0);

}

function draw() {
  background(220);
}