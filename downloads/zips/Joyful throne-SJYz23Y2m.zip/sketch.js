var rect = 300;
function setup() {
  createCanvas(400, 400);
  ellipse(200,200,rect);
}