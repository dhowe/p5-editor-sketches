function setup() {
  createCanvas(600, 400);
  background(0);
  noStroke();
}

function draw() {

  ellipse(mouseX, mouseY, 20);
}
