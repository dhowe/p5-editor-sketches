let x = -1, y = -1;

function setup() {
  createCanvas(400, 400);
}
