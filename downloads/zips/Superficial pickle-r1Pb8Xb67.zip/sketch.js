function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(220);
}