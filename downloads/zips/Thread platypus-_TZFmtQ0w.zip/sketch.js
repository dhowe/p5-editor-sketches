function setup() {
  createCanvas(400, 400);
  square(100,100,50);
  circle(100,100,50);
}

