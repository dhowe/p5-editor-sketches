let txt;

function preload() {
  txt = loadString("");
}

function setup() {
  createCanvas(400, 400);
}

