
var json;
function setup() {
  createCanvas(400, 400);
  loadStrings("", function(lines){
    
  });
}

function draw() {
  background(220);
}