let haiku = {
  start: "$5line.ucf() % $7plus5",
  '5line': "the $nnnn | $nnnnn | $vp4 again",
  '7plus5': "(I wake and look for water % $vp5) | ($12sen $tree)",
  
  aaaa: "isolated | suffocated",
  aaa: "exciting | beautiful | adorable",
  rrr: "silently | secretly | painfully | happily | violently | together",
  vvv: "fantasize | remember",

  nn: "people | (the | a) man | women | (the | a) boy | (the | a) girls | children | rabbit | (the | a) dog | racoon | river | mountain | buddha | city | ocean",
  vv: "whisper | blossom | recite | swing | speak | twist | appear | forgive | forget | believe | betray | adore | follow | question",
  aa: "sadly | calmly | coldly",

  n: "kids | clouds | trees | leaves | rain | birds | snow | grass | smoke",
  a: "sad | tall | hot | drunk | plain | grey",
  v: "sing | cry | bow | rise | bloom | dance | drink | fall",

  '12sen': "(((beetle|termite) eats | ant burrows).art() (silently | placidly) % into the) | ((spider | inchworm).art() dangles % from the)",
  tree: "(chestnut | cedar | old (gum | tea)) tree",
    
  nnn: "a black rose | white daisies | sakura | rosemary | a yellow cat | oranges | cool moonlight | dark forest | huge mountain",
  nnnn: "(mountain | silent) village | (evening | morning) sun | (winter | summer) flower | (star | sky) above",
  nnnnn: "the (autumn | summer) moonlight",
  
  vp4: "singing like birds | drifting like snow | falling like (rain | leaves)",
  vp5: "crying like a child | singing like a bird | drifting like the snow | falling like (the rain | a leaf)" 
}