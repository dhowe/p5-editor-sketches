let N = 10, result = '';
let lines, model = {};

function preload() {
  lines = loadStrings('kafka.txt');
}

function setup() {
  
  createModel(lines);
}

function selectNext(sofar) {

}

function createModel(lines) {

}
