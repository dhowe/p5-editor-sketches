function setup() {
  createCanvas(10, 10);
}
